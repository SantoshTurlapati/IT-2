"""Command-line interface for DataLens."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .analyzer import analyze_csv, analyze_dataframe
from .cleaner import clean_dataframe


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Profile a CSV file and optionally clean common data issues."
    )
    parser.add_argument("csv_file", help="Path to the input CSV file")
    parser.add_argument("--output-dir", default="output", help="Directory for output files")
    parser.add_argument("--drop-duplicates", action="store_true", help="Remove duplicate rows")
    parser.add_argument("--fill-missing", action="store_true", help="Fill missing values")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    source = Path(args.csv_file)
    output_dir = Path(args.output_dir)

    try:
        dataframe, original_report = analyze_csv(str(source))
        cleaned = clean_dataframe(
            dataframe,
            drop_duplicates=args.drop_duplicates,
            fill_missing=args.fill_missing,
        )
        output_dir.mkdir(parents=True, exist_ok=True)
        cleaned.to_csv(output_dir / "cleaned.csv", index=False)

        report = {
            "input_file": source.name,
            "original_profile": original_report,
            "cleaned_profile": analyze_dataframe(cleaned),
            "cleaning_options": {
                "drop_duplicates": args.drop_duplicates,
                "fill_missing": args.fill_missing,
            },
        }
        (output_dir / "report.json").write_text(
            json.dumps(report, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except (OSError, ValueError, UnicodeDecodeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    print(f"Analysis complete. Results saved in: {output_dir.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
