"""DataLens CSV profiling package."""

__version__ = "1.0.0"
