"""Dataset profiling and data-quality analysis."""
from __future__ import annotations

from typing import Any
import pandas as pd


def analyze_dataframe(df: pd.DataFrame) -> dict[str, Any]:
    """Return a JSON-serializable profile of a DataFrame."""
    if df is None:
        raise ValueError("DataFrame cannot be None")

    columns: dict[str, Any] = {}
    for name in df.columns:
        series = df[name]
        column_info: dict[str, Any] = {
            "dtype": str(series.dtype),
            "missing_count": int(series.isna().sum()),
            "missing_percentage": round(float(series.isna().mean() * 100), 2),
            "unique_count": int(series.nunique(dropna=True)),
        }
        if pd.api.types.is_numeric_dtype(series):
            numeric = series.describe()
            column_info["numeric_summary"] = {
                key: (None if pd.isna(value) else float(value))
                for key, value in numeric.items()
            }
        columns[str(name)] = column_info

    return {
        "row_count": int(len(df)),
        "column_count": int(len(df.columns)),
        "duplicate_row_count": int(df.duplicated().sum()),
        "columns": columns,
    }


def analyze_csv(path: str) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Load a CSV and return the DataFrame and its profile."""
    try:
        df = pd.read_csv(path)
    except FileNotFoundError:
        raise
    except pd.errors.EmptyDataError as exc:
        raise ValueError(f"CSV file is empty: {path}") from exc
    except pd.errors.ParserError as exc:
        raise ValueError(f"Could not parse CSV file: {path}") from exc

    if len(df.columns) == 0:
        raise ValueError("CSV must contain at least one column")
    return df, analyze_dataframe(df)
