"""Explicit, predictable data-cleaning operations."""
from __future__ import annotations

import pandas as pd


def clean_dataframe(
    df: pd.DataFrame,
    *,
    drop_duplicates: bool = False,
    fill_missing: bool = False,
) -> pd.DataFrame:
    """Return a cleaned copy; never mutate the caller's DataFrame."""
    if df is None:
        raise ValueError("DataFrame cannot be None")

    cleaned = df.copy()
    if drop_duplicates:
        cleaned = cleaned.drop_duplicates()

    if fill_missing:
        for column in cleaned.columns:
            if not cleaned[column].isna().any():
                continue
            if pd.api.types.is_numeric_dtype(cleaned[column]):
                median = cleaned[column].median()
                cleaned[column] = cleaned[column].fillna(median)
            else:
                modes = cleaned[column].mode(dropna=True)
                replacement = modes.iloc[0] if not modes.empty else "Unknown"
                cleaned[column] = cleaned[column].fillna(replacement)

    return cleaned
