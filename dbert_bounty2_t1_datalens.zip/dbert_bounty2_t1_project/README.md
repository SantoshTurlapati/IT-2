# DataLens — CSV Data Quality & Analysis Tool

A small, modular Python project that profiles CSV datasets, detects common data-quality issues, and exports a JSON summary plus cleaned CSV.

## Features
- Reads CSV files with Pandas.
- Reports row/column counts, column types, missing values, duplicate rows, and numeric summaries.
- Supports configurable duplicate removal and missing-value handling.
- Exports a cleaned CSV and a machine-readable JSON report.
- Includes unit tests for normal inputs and edge cases.

## Requirements
- Python 3.10+
- pandas

## Setup (Windows PowerShell)
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Run
Use the included sample:
```powershell
python -m datalens.cli data/sample_sales.csv --output-dir output
```

Or provide your own CSV:
```powershell
python -m datalens.cli path\to\your_file.csv --output-dir output
```

Optional cleaning:
```powershell
python -m datalens.cli data/sample_sales.csv --output-dir output --drop-duplicates --fill-missing
```

The output directory contains:
- `cleaned.csv` — processed dataset
- `report.json` — data profile and quality findings

## Run tests
```powershell
python -m unittest discover -s tests -v
```

## Project structure
```text
dbert_bounty2_t1_project/
├── datalens/
│   ├── __init__.py
│   ├── analyzer.py
│   ├── cleaner.py
│   └── cli.py
├── data/
│   └── sample_sales.csv
├── tests/
│   ├── test_analyzer.py
│   └── test_cleaner.py
├── requirements.txt
└── README.md
```

## Design
- `analyzer.py` contains profiling and data-quality logic.
- `cleaner.py` contains opt-in cleaning operations.
- `cli.py` handles arguments, orchestration, and file output.
- Tests use temporary data and do not depend on external services.

## Notes
Cleaning is opt-in: by default the tool preserves the input data and reports issues without silently changing values. Numeric missing values are filled with the column median; non-numeric missing values are filled with the most frequent value when `--fill-missing` is selected.

## GitHub submission
1. Create a new public repository, for example `dbert-bounty2-t1-datalens`.
2. Extract this ZIP file.
3. Open the extracted folder in VS Code.
4. Run the setup, sample command, and tests above.
5. Commit and push:
```powershell
git init
git add .
git commit -m "Build DataLens CSV quality analyzer"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/dbert-bounty2-t1-datalens.git
git push -u origin main
```
6. Paste the repository URL into DBERT's **GitHub Repository or Live App URL** field.

## Scope clarification
The task page text provided so far contains only general implementation guidelines and no detailed technical briefing. This is a complete general-purpose sample project, but check the expanded **Technical Briefing & Requirements** section on DBERT before submitting; any hidden task-specific requirements should take priority.
