import unittest
import pandas as pd

from datalens.analyzer import analyze_dataframe


class AnalyzeDataFrameTests(unittest.TestCase):
    def test_profile_counts_and_quality(self):
        frame = pd.DataFrame({
            "score": [10, 20, None],
            "team": ["A", "A", "B"],
        })
        report = analyze_dataframe(frame)
        self.assertEqual(report["row_count"], 3)
        self.assertEqual(report["column_count"], 2)
        self.assertEqual(report["columns"]["score"]["missing_count"], 1)
        self.assertEqual(report["columns"]["team"]["unique_count"], 2)

    def test_duplicate_count(self):
        frame = pd.DataFrame({"id": [1, 1, 2]})
        self.assertEqual(analyze_dataframe(frame)["duplicate_row_count"], 1)

    def test_empty_dataframe(self):
        report = analyze_dataframe(pd.DataFrame())
        self.assertEqual(report["row_count"], 0)
        self.assertEqual(report["column_count"], 0)


if __name__ == "__main__":
    unittest.main()
