import unittest
import pandas as pd

from datalens.cleaner import clean_dataframe


class CleanDataFrameTests(unittest.TestCase):
    def test_cleaning_is_opt_in(self):
        frame = pd.DataFrame({"value": [1, None, 1], "name": ["A", "B", "A"]})
        result = clean_dataframe(frame)
        self.assertEqual(len(result), 3)
        self.assertTrue(result["value"].isna().any())

    def test_drop_duplicates_and_fill_missing(self):
        frame = pd.DataFrame({"value": [2.0, None, 2.0], "name": ["A", "B", "A"]})
        result = clean_dataframe(frame, drop_duplicates=True, fill_missing=True)
        self.assertEqual(len(result), 2)
        self.assertFalse(result.isna().any().any())
        self.assertEqual(result.loc[1, "value"], 2.0)

    def test_input_is_not_mutated(self):
        frame = pd.DataFrame({"value": [1.0, None]})
        clean_dataframe(frame, fill_missing=True)
        self.assertTrue(frame["value"].isna().any())


if __name__ == "__main__":
    unittest.main()
